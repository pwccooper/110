function save() {

    var newRep = {
        name: "First name: ",
        lastName: "Last name: ",
        phoneNumber: num * 1

    };

    console.log(newRep);

    $.ajax({
        type: 'POST',
        url: '/representatitves/save',
        contentType: 'application/json; charset utf-8',
        data: JSON.stringify(newRep),
        success: function (res) {
            console.log("Success: ", res);
        },
        error: function (error) {
            console.log("***Error", error);
        }
    });
}


function init() {
    console.log("init create rep");


}

window.onload = init;