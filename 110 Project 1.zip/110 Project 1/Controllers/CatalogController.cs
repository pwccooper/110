using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using _110_Project_1.Models;
using project.Models;

namespace project.Controllers
{

    public class CatalogController : Controller
    {

        private DataContext Context;

        public CatalogController(DataContext Context)
        {
            Context = Context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        /*  public IActionResult GetCatalog()
         {
             List<Car> list = Context.Cars.Where(car => c.Make != null).ToList();

             return Json(list);
         } */


        public IActionResult GetCatalog()
        {
            Console.WriteLine("Requested GetCalog");

            List<Car> list = new List<Car>();

            Car car = new Car();
            car.Id = 1;
            car.Make = "Nissan";
            car.Model = "GT-R Nismo GT3";
            car.Year = 201;
            car.HP = 600;
            car.RentPrice = 750;
            car.Picture = "https://cdn.motor1.com/images/mgl/Bbg6A/s1/2018-nissan-gt-r-nismo-gt3.jpg";

            list.Add(car);



            return Json(list);

        }

        [HttpPost]

        public IActionResult CreateCar([FromBody] Car newCar)
        {
            Console.WriteLine("Getting to CreateCar", newCar);

            Context.Cars.Add(newCar);
            Context.SaveChanges();

            Console.WriteLine();
            Console.WriteLine("*Saved!*");
            Console.WriteLine();

            return Json(newCar);
        }
    }

};

