using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using project.Models;
using Microsoft.EntityFrameworkCore;


namespace project.Controllers
{

    public class RepresentativeController : Controller
    {

        private DataContext Context;
        public RepresentativeController(DataContext context)
        {
            Context = context;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetList()
        {
            return Ok();
        }

        public IActionResult Save([FromBody] Representative newRep)
        {

            Console.WriteLine("\n\n\n\n");
            Console.WriteLine(newRep.Name, newRep.LastName, newRep.PhoneNumber);
            Console.WriteLine("\n\n\n\n");
            return Ok();
        }
    }
}
