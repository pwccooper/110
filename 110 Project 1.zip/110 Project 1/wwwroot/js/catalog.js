function getCatalogFromServer() {


    $.ajax({
        url: '/Catalog/GetCatalog',
        type: 'GET',
        success: function (data) {
            console.log("Response from Server", data);
            displayCatalog(data);
        },
        error: function (error) {
            console.error("Error on com", error);
        }
    });
}

function displayCatalog(list) {
    for (var i = 0; i < list.lenght; i++) {
        var car = list[i];

        var carContainer = $("#carList");
        var carTemplate =
            `
        <div class="card" style="width: 18rem;">
        <div class="card-header">
         <img src="${car.picture}" class="card-img">
        </div>
        <ul class="list-group list-group-flush">
          <li class="list-group-item">${car.Make} ${car.Model}</li>
          <li class="list-group-item">${car.description}</li>
          <li class="list-group-item">Cargo:${car.cargo} HP:${car.HP}   </li>
            <button class="btn btn-primary float-right" onclick="rent(${card.id})">Rent Me </button>
          </ul>
      </div>
        `;

        carContainer.append(carTemplate);
    }
}

function init() {
    console.log("Initialize Catalog");

    getCatalogFromServer();
}

document.onload = init;